# Changelog

All notable changes to Garment POS are documented here.

## [0.2.0] - 2026-11-12 — Phase 2: Authentication, Security & Settings

### Added
- Database schema **version 2** (migration from v1 preserves
  app_settings): users, roles, permissions, role_permissions,
  user_permissions, audit_logs, number_sequences.
- First-run Owner/Admin setup (username, password, PIN) with a
  one-time Recovery Key; only its PBKDF2 hash is stored.
- Offline login by username+password or user+PIN (4–6 digits);
  PBKDF2-HMAC-SHA256 salted hashing via `cryptography` 2.9.0 —
  never plain SHA-256, never plain text.
- Roles (Admin/Manager/Salesman) with a seeded, editable
  permission matrix plus per-user overrides; Salesman cannot see
  purchase price, product cost or profit by default.
- User management: create/edit/enable/disable users, password
  reset, PIN set — all audit-logged.
- Forgot-password: Admin resets others; owner resets own password
  with the Recovery Key (audited as `password.recovery_reset`).
- Auto lock after configurable inactivity (default 5 min) with a
  lock screen (password/PIN unlock), plus manual lock and sign out.
- Audit log viewer screen.
- Full shop settings: profile (name, address, GSTIN, state/code,
  phone, logo path), invoice prefix with live next-number preview,
  tax defaults, round-off, printer name/paper size, language,
  Retail Mode switch, auto-lock minutes, auto-backup preference.
- Financial-year invoice sequencing (`GW/2026-27/0001`) backed by
  the number_sequences table inside a database transaction.
- Dashboard: signed-in user/role header, wholesale/retail mode
  chip, live Users/Permissions/Audit/Settings tiles by permission.
- Tests: password hasher, recovery key, financial year + invoice
  sequence, auth repository (login, PIN, disable, permissions,
  recovery, audit), retail mode toggle, schema v2 tables.

### Notes
- Sessions are memory-only: restarting the app requires login.
- `app_database.g.dart` was regenerated for the 8-table schema;
  as before, `dart run build_runner build` on a dev PC reproduces
  it from drift_dev.

## [0.1.1] - 2026-11-12 — Phase 1 fix (first PC run)

### Fixed
- `settings_repository.dart`: added the missing
  `app_constants.dart` import — `flutter analyze` reported
  "Undefined name 'AppConstants'" on the first Windows run.
- README setup guide: documented deleting the sample
  `test/widget_test.dart` that `flutter create .` generates (it
  references a non-existent `MyApp` class).

## [0.1.0] - 2026-11-12 — Phase 1: Foundation & Project Architecture

### Added
- Flutter project skeleton with feature-first folder structure
  (`core/`, `data/`, `features/`, `l10n/`).
- Pinned dependencies verified against pub.dev on 2026-11-12:
  flutter_riverpod 3.5.0, go_router 18.1.4, drift 2.35.4,
  sqlite3 3.9.1, path_provider 2.1.5, drift_dev 2.35.3.
  The End-of-Life `sqlite3_flutter_libs` package is deliberately not
  used; `sqlite3` 3.x bundles native SQLite via Dart build hooks.
- Material 3 theme (light/dark) with bundled Noto Sans Bengali font.
- Responsive layout foundation: mobile / tablet / desktop device
  classes with breakpoint helpers.
- Bengali (default) + English localization via ARB files and a
  database-persisted language switcher.
- Drift + SQLite database, schema **version 1**: `app_settings`
  key-value table, migration strategy skeleton, foreign keys on.
- `SettingsRepository` with typed string/int/bool access.
- `Money` utility: integer-paise arithmetic, Indian digit grouping,
  half-up percentage and round-off helpers.
- Dashboard shell showing real database status (connected, schema
  version, settings count) and module tiles labelled by delivery
  phase. No placeholder business numbers.
- Foundation Settings screen (language, persisted to SQLite).
- Tests: money, responsive breakpoints, database/settings,
  localization switching (Bengali → English).
- Documentation: README, ROADMAP, docs/ARCHITECTURE,
  docs/DATABASE_SCHEMA, docs/TESTING, docs/BUILD_WINDOWS,
  docs/BUILD_ANDROID.

### Notes
- The Arena sandbox has no Flutter/Dart toolchain and the Dart SDK
  download host is blocked there, so `flutter pub get`,
  `flutter analyze` and `flutter test` could not be executed in the
  sandbox. They must be run on the development PC (see
  docs/TESTING.md) and any failure reported back for fixing.
- `android/` and `windows/` runner folders are generated locally with
  `flutter create .` (see README > First-time setup).
